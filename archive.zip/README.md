# BerimMasjed
بریم مسجد



Getting Started

Download the installer for Node.js 6 or greater.

Install the ionic CLI globally: npm install -g ionic

Clone this repository: git clone 
Run npm install from the project root.

Run ionic serve in a terminal from the project root.

Profit. tada
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
