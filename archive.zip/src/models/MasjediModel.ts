export interface MasjediModel {
    id:          string;
    name:        string;
    personalPic: string;
    jens:        string;
    birthPlace:  string;
    marriage:    string;
    field:       string;
    provinceId:  string;
}