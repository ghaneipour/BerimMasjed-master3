<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserControllers extends BaseController
{
    public function MyUserVoid()
    {
        return 'ok';
    }
}
?>