<?php


namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class PostControllers extends Controllers
{

	public function MyPostVoid()
	{
		//return 'ok';
	}

}
 


?>